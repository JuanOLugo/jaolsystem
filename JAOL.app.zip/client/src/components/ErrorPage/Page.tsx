import { Navigate } from 'react-router-dom'

function Page() {
  return <Navigate to="/" />
}

export default Page