import UserSession from "./Components/UserSession"



function SettingsPage() {
  return (
    <div>
        <UserSession/>
    </div>
  )
}

export default SettingsPage